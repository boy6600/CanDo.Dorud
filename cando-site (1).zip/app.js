(function(){
var $=function(i){return document.getElementById(i)};
// منو موبایل
if($('mb'))$('mb').onclick=function(){$('mn').classList.toggle('open')};
// انیمیشن ظاهر شدن
var els=document.querySelectorAll('.rv'),io='IntersectionObserver' in window?new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.1}):null;
els.forEach(function(e){io?io.observe(e):e.classList.add('in')});

// ارسال ثبت‌نام: ذخیره روی هاست (save.php) + واتساپ
var WA='989338819703';
window.sendReg=function(d,msgId){
  var fd=new FormData();for(var k in d)fd.append(k,d[k]);
  try{fetch('save.php',{method:'POST',body:fd}).catch(function(){})}catch(e){}
  var t='ثبت‌نام CanDo\nنام: '+d.name+'\nموبایل: '+d.phone+'\nگروه سنی: '+d.age+'\nدوره: '+d.course+'\nسطح: '+(d.level||'-');
  window.open('https://wa.me/'+WA+'?text='+encodeURIComponent(t),'_blank','noopener');
  if(msgId&&$(msgId))$(msgId).textContent='ثبت شد؛ پیام واتساپ برای ارسال باز شد.';
};
window.okPhone=function(p){return /^(\+98|0)?9\d{9}$/.test(p.replace(/\s/g,''))};

// فرم ثبت‌نام
if($('rf')){
  var m=location.search.match(/level=([A-C][12])/);if(m&&$('level'))$('level').value=m[1];
  $('rf').onsubmit=function(e){e.preventDefault();
    var d={name:$('name').value.trim(),phone:$('phone').value.trim(),age:$('age').value,course:$('course').value,level:$('level').value};
    if(d.name.length<3||!okPhone(d.phone)){$('rm').className='msg err';$('rm').textContent='نام یا شماره موبایل معتبر نیست.';return}
    $('rm').className='msg';sendReg(d,'rm');
  };
}

// آزمون تعیین سطح
if($('quiz')){
  var Q=[
  ['She ___ a teacher.','am|is|are',1],['I ___ two brothers.','have|has|am',0],['___ you like pizza?','Do|Does|Is',0],['This is ___ apple.','a|an|the',1],['They ___ at home now.','is|am|are',2],
  ['He ___ to the gym yesterday.','go|went|goes',1],['I’m ___ than my sister.','taller|tall|tallest',0],['We ___ TV when you called.','watch|were watching|are watching',1],['There isn’t ___ milk in the fridge.','some|any|a',1],['She’s going ___ a doctor tomorrow.','see|to see|seeing',1],
  ['If it rains, we ___ at home.','stay|will stay|stayed',1],['I have lived here ___ 2019.','for|since|from',1],['You ___ smoke here. It’s forbidden.','don’t have to|mustn’t|needn’t',1],['The letter ___ yesterday.','sent|was sent|is sent',1],['He asked me where ___.','I lived|did I live|do I live',0],
  ['If I ___ more time, I’d learn French.','have|had|will have',1],['I wish I ___ speak Spanish.','can|could|would',1],['She suggested ___ the meeting.','to postpone|postponing|postpone',1],['By next year, I ___ my degree.','will finish|will have finished|finish',1],['Hardly ___ the door when the phone rang.','I had opened|had I opened|I opened',1]];
  var L=[['A1','مقدماتی','مکالمه مقدماتی / عمومی ۱'],['A2','پایه','مکالمه پایه / عمومی ۲'],['B1','متوسط','مکالمه متوسط / آیلتس پایه'],['B2','بالاتر از متوسط','پیشرفته / آیلتس و تافل'],['C1','پیشرفته','تسلط و آمادگی آزمون‌های بین‌المللی']];
  var i=0,s=0,p=-1,u={},lv=0;
  var show=function(n){['st1','st2','st3'].forEach(function(x){$(x).classList.toggle('hide',x!=='st'+n)});window.scrollTo({top:0})};
  $('go').onclick=function(){
    u={name:$('name').value.trim(),phone:$('phone').value.trim(),age:$('age').value,course:'تعیین سطح'};
    if(u.name.length<3||!okPhone(u.phone)){$('er').textContent='نام و شماره موبایل معتبر را وارد کنید.';return}
    $('er').textContent='';i=0;s=0;draw();show(2)};
  function draw(){p=-1;var q=Q[i];$('cn').textContent='سؤال '+(i+1)+' از '+Q.length;$('pb').style.width=(i/Q.length*100)+'%';$('q').textContent=q[0];$('op').innerHTML='';
    q[1].split('|').forEach(function(t,k){var b=document.createElement('button');b.className='opt';b.textContent=t;b.onclick=function(){p=k;[].forEach.call($('op').children,function(c,j){c.classList.toggle('sel',j===k)})};$('op').appendChild(b)});
    $('nx').textContent=i===Q.length-1?'پایان آزمون':'سؤال بعدی'}
  $('nx').onclick=function(){if(p<0)return;if(p===Q[i][2])s++;i++;if(i<Q.length){draw();return}
    lv=s<=4?0:s<=8?1:s<=12?2:s<=17?3:4;$('lv').textContent=L[lv][0];$('lt').textContent='سطح تقریبی شما: '+L[lv][1];
    $('lc').textContent='کلاس پیشنهادی: '+L[lv][2];$('sc').textContent='نمره: '+s+' از '+Q.length+' (سطح نهایی با مشاوره آموزشگاه مشخص می‌شود)';
    $('rg').href='register.html?level='+L[lv][0];show(3)};
  $('wa').onclick=function(){u.level=L[lv][0]+' ('+L[lv][1]+') - '+s+'/'+Q.length;sendReg(u,'wm')};
}
})();

(function(){document.querySelectorAll('.fc').forEach(function(c){c.onclick=function(){c.classList.toggle('on')}});
document.querySelectorAll('.spk').forEach(function(b){b.onclick=function(e){e.stopPropagation();try{speechSynthesis.cancel();var u=new SpeechSynthesisUtterance(b.dataset.t);u.lang=b.dataset.l||'en-US';u.rate=.9;speechSynthesis.speak(u)}catch(x){}}})})();

(function(){document.querySelectorAll('.mq').forEach(function(q){var os=q.querySelectorAll('.opt');os.forEach(function(b,i){b.onclick=function(){os.forEach(function(x,j){x.classList.remove('ok','no');if(j==q.dataset.ok)x.classList.add('ok')});if(i!=q.dataset.ok)b.classList.add('no')}})})})();
