<?php
// ذخیره ثبت‌نام‌ها روی هاست. فایل registrations.php از بیرون خوانده نمی‌شود.
$f=__DIR__.'/registrations.php';
if(!file_exists($f))file_put_contents($f,"<?php http_response_code(403);exit; ?>\n");
$c=fn($k)=>str_replace(["\n","\r","|"]," ",substr($_POST[$k]??'',0,120));
$line=date('Y-m-d H:i')." | ".$c('name')." | ".$c('phone')." | ".$c('age')." | ".$c('course')." | ".$c('level')."\n";
file_put_contents($f,$line,FILE_APPEND|LOCK_EX);
echo 'ok';
